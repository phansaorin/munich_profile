<ol class="breadcrumb">
  <li><?php echo anchor("munich_admin","Dashboard"); ?></li>
  <li><?php echo anchor("supplier/list_record","Manage"); ?></li>
  <?php if($this->session->userdata('search')){?>
  <li><?php echo anchor("extra_products/search_extra_products","Search"); ?></li>
  <?php }?>
  <li>Edit</li>
</ol>
<h1 class="action_page_header">Edit Extra Products</h1>

<?php  echo form_open('extra_products/edit_extra_products/'.$this->uri->segment(3), 'class="form-horizontal"'); ?>
<?php
        foreach ($get_extraproducts->result() as $row) {
            ?>
    <div class="form-group">
        <label class="col-sm-2 control-label">Name <span class="require">*</span> :</label>
        <div class="col-sm-4">
            <?php
                $txtName = array('name' => 'old_txtName','value'=> $row->ep_name,'class' => 'form-control');
                echo form_input($txtName); 
                ?>
            <span style="color:red;"><?php echo form_error('old_txtName'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Per Person<span class="require">*</span> :</label>
        <div class="col-sm-2">
            <?php 
                echo form_dropdown('old_txtPerperson', $txtPerperson, $row->ep_perperson,'class="form-control"'); 
            ?>
            <span style="color:red;"><?php echo form_error('old_txtPerperson'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Per Booking<span class="require">*</span> :</label>
        <div class="col-sm-2">
            <?php 
                echo form_dropdown('old_txtPerbooking', $txtPerbooking, $row->ep_perbooking,'class="form-control"'); 
            ?>
            <span style="color:red;"><?php echo form_error('old_txtPerbooking'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Text for booking form <span class="require">*</span> :</label>
        <div class="col-sm-4">
            <?php 
                $txtBooking = array('name'=>'old_txtBooking', 'class' => 'form-control textarea', 'value' => $row->ep_bookingtext);
                echo form_textarea($txtBooking);
            ?>
            <span style="color:red;"><?php echo form_error('old_txtBooking'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">File input <span class="require">*</span> :</label>
        <div class="col-sm-4">
            <?php 
                $photos = array();
                    if($txtPhotos->num_rows > 0){   
                        foreach($txtPhotos->result() as $value){
							$photos['0'] = "--- select ---";
                            $photos[$value->photo_id] = $value->pho_name;

                        }
                    }
            echo form_dropdown('old_txtPhotos', $photos, $row->photo_id, 'class="form-control"');  
            ?>
            <span style="color:red;"><?php echo form_error('old_txtPhotos'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Text for E-ticket <span class="require">*</span> :</label>
        <div class="col-sm-4">
            <?php
                $txtEticket = array('name'=>'old_txtEticket', 'class' => 'form-control textarea', 'value' => $row->ep_etickettext); 
                echo form_textarea($txtEticket);
            ?>
            <span style="color:red;"><?php echo form_error('old_txtEticket'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Purchase Price <span class="require">*</span> :</label>
        <div class="col-sm-2">
            <?php
                $purchasePrice = array('name' => 'old_purchasePrice','class' => 'form-control', 'value' => $row->ep_purchaseprice);
                echo form_input($purchasePrice);
            ?>
        </div>
        <div class="col-sm-4">
            <span style="color:red;"><?php echo form_error('old_purchasePrice'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Sale Price <span class="require">*</span> :</label>
        <div class="col-sm-2">
            <?php
                $salePrice = array('name' => 'old_salePrice','class' => 'form-control','value' => $row->ep_saleprice);
                echo form_input($salePrice);
            ?>
        </div>
        <div class="col-sm-4">
            <span style="color:red;"><?php echo form_error('old_salePrice'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Original Stock <span class="require">*</span> :</label>
        <div class="col-sm-2">
            <?php
                $originalStock = array('name' => 'old_originalStock','class' => 'form-control', 'value' => $row->ep_originalstock);
                echo form_input($originalStock);
                echo form_hidden('old_originalStock', $row->ep_originalstock);
            ?>
        </div>
        <div class="col-sm-4">
            <span style="color:red;"><?php echo form_error('old_originalStock'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Actual Stock <span class="require">*</span> :</label>
        <div class="col-sm-2">
            <?php
                $actualStock = array('name' => 'old_actualStock','class' => 'form-control', 'value'=> $row->ep_actualstock);
                echo form_input($actualStock);
            ?>
        </div>
        <div class="col-sm-4">
            <span style="color:red;"><?php echo form_error('old_actualStock'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Date Provider :</label>
        <div class="col-sm-4">
            <div id="alert">
                <strong></strong>
                <?php
                    $txtProvider = array('id'=>'dp1' ,'name' => 'old_txtProvider', 'class' => 'form-control','data-date-format'=>'yyyy-mm-dd','style'=>'width:210px;', 'value' => $row->ep_providerdate);
                    echo form_input($txtProvider);
                ?>
            </div>
            <span style="color:red;"><?php echo form_error('old_txtProvider'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Payed :</label>
        <div class="col-sm-4">
            <strong></strong>
            <?php
                $txtPayed = array( 'id'=>'dp2','name' => 'old_txtPayed', 'class' => 'form-control','data-date-format'=>'yyyy-mm-dd','style'=>'width:210px;', 'value' => $row->ep_payeddate);
                echo form_input($txtPayed);
            ?>
            <span style="color:red;"><?php echo form_error('old_txtPayed'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Deadline :</label>
        <div class="col-sm-4">
            <?php
                $txtDeadline = array( 'id'=>'dp3','name' => 'old_txtDeadline', 'class' => 'form-control','data-date-format'=>'yyyy-mm-dd','style'=>'width:210px;', 'value' => $row->ep_deadline);
                echo form_input($txtDeadline);
            ?>
            <span style="color:red;"><?php echo form_error('old_txtDeadline'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Text for admin :</label>
        <div class="col-sm-4">
            <?php
                $txtAdmin = array('name'=>'old_txtAdmin', 'class' => 'form-control textarea', 'value' => $row->ep_admintext); 
                echo form_textarea($txtAdmin);
            ?>
            <span style="color:red;"><?php echo form_error('old_txtAdmin'); ?></span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Status<span class="require">*</span> :</label>
        <div class="col-sm-4">
            <?php echo form_dropdown('old_txtStatus', $txtStatus,$row->ep_status ,'class="form-control"'); ?>
            <span style="color:red;"><?php echo form_error('old_txtStatus'); ?></span>
        </div>
    </div>
  
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <?php 
                echo form_submit('edit_extra_products', 'Update',"class='btn btn-primary check_value'");
				echo '  ';
				echo anchor('extra_products/list_record', form_button('close', 'Cancel', "class='btn btn-sm btn-default'"));
            ?>
        </div>
    </div>
<?php } ?>
<!-- </form> -->
            <?php
echo form_close();
?>