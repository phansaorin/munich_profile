﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void submitbtn_Click(object sender, EventArgs e)
    {
        firstname.Text = fname.Text;
        lastname.Text = lname.Text;

        lblSelectedText.Text = ddlGender.SelectedItem.Text;
        maritaltitle.Text = marital.SelectedItem.Text;
        dobd.Text = day.SelectedItem.Text +"/";
        dobm.Text = month.SelectedItem.Text + "/";
        doby.Text = year.SelectedItem.Text;

        nation.Text = nationality.SelectedItem.Text;
        handphone.Text = hp.Text;
        email.Text = em.Text;
        housename.Text = house.Text;
        streetname.Text = street.Text;
        sangkatname.Text = sangkat.Text;
        khanname.Text = khan.Text;
        institutename.Text = institute.Text;
        institutebachelorname.Text = institutebachelor.Text;
        institutemasterdegreename.Text = instituremasterdegree.Text;
        

    }
}