﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /*Student stuObj = new Student();
        stuObj.StudentFirstName = "Chhingchhing";
        stuObj.StudentLastName = "HEM";
        stuObj.StudentEmail = "chhing99@gmail.com";
        stuObj.StudentGender = "Female";
        stuObj.StudentMajor = "Web and Database Programming";
        stuObj.StudentAge = 22;
        Response.Write("Student's FirstName:" + stuObj.StudentFirstName + "<br/>");
        Response.Write("Student's LastName:" + stuObj.StudentLastName + "<br/>");
        Response.Write("Student's Email:" + stuObj.StudentEmail + "<br/>");
        Response.Write("Student's Gender:" + stuObj.StudentGender + "<br/>");
        Response.Write("Student's Major:" + stuObj.StudentMajor + "<br/>");
        Response.Write("Student's Age:" + stuObj.StudentAge + "<br/>");*/
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Student stuObj = new Student();
        // Get value from a form html
        stuObj.StudentFirstName = Request.Form["FirstName"];
        stuObj.StudentLastName = Request.Form["LastName"];
        stuObj.StudentEmail = Request.Form["Email"];
        stuObj.StudentGender = Request.Form["Gender"];
        stuObj.StudentMajor = Request.Form["Major"];
        stuObj.StudentAge = Convert.ToInt32(Request.Form["Age"]);

        Session["SessionFirstName"] = stuObj.StudentFirstName; //Setter
        Session["SessionLastName"] = stuObj.StudentLastName; //Setter
        Session["SessionEmail"] = stuObj.StudentEmail; //Setter
        Session["SessionGender"] = stuObj.StudentGender; //Setter
        Session["SessionMajor"] = stuObj.StudentMajor; //Setter
        Session["SessionAge"] = stuObj.StudentAge; //Setter
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        Student stuObj = new Student();
        /*Response.Write("Student's FirstName:" + stuObj.StudentFirstName + "<br/>");
        Response.Write("Student's LastName:" + stuObj.StudentLastName + "<br/>");
        Response.Write("Student's Email:" + stuObj.StudentEmail + "<br/>");
        Response.Write("Student's Gender:" + stuObj.StudentGender + "<br/>");
        Response.Write("Student's Major:" + stuObj.StudentMajor + "<br/>");
        Response.Write("Student's Age:" + stuObj.StudentAge + "<br/>");*/


        String FirstName = (String)Session["SessionFirstName"]; //Getter
        String LastName = (String)Session["SessionLastName"]; //Getter
        String Email = (String)Session["SessionEmail"]; //Getter
        String Gender = (String)Session["SessionGender"]; //Getter
        String Major = (String)Session["SessionMajor"]; //Getter
        int Age = (Int32)Session["SessionAge"]; //Getter

        Response.Write("Student's FirstName:" + FirstName + "<br/>");
        Response.Write("Student's LastName:" + LastName + "<br/>");
        Response.Write("Student's Email:" + Email + "<br/>");
        Response.Write("Student's Gender:" + Gender + "<br/>");
        Response.Write("Student's Major:" + Major + "<br/>");
        Response.Write("Student's Age:" + Age + "<br/>");
    }

    protected void btnDefaultStudent_Click(object sender, EventArgs e)
    {
        Student stuObj = new Student();
        stuObj.GetDefaultStudent();
        
        // Get session from Student Class
        /*String FirstName = (String)Session["FirstName"]; //Getter
        Response.Write(FirstName);*/

    }

    protected void btnClearSession_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
    }

    protected void btnDescription_Click(object sender, EventArgs e)
    {
        Response.Write(Student.ShowIntroduction());

    }

}