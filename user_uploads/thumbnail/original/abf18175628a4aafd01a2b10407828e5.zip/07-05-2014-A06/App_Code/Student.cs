﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

/// <summary>
/// Summary description for Student
/// </summary>
public class Student
{
    String firstName;
    String lastName;
    String gender;
    String email;
    String major;
    int age;


	public Student()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public String StudentFirstName {
        set { firstName = value; }
        get { return firstName; }
    }

    public String StudentLastName {
        set { lastName = value; }
        get { return lastName; }
    }

    public String StudentGender {
        set { gender = value; }
        get { return gender; }
    }

    public String StudentEmail {
        set { email = value; }
        get { return email; }
    }

    public String StudentMajor {
        set { major = value; }
        get { return major; }
    }

    public int StudentAge {
        set { age = value; }
        get { return age; }
    }

    // Set Method
    public void GetDefaultStudent() {
        Student stuObj = new Student();
        stuObj.StudentFirstName = "Sokheng";
        stuObj.StudentLastName = "KHAM";
        stuObj.StudentEmail = "sokheng.kham@gmail.com";
        stuObj.StudentGender = "Male";
        stuObj.StudentMajor = "ASP.NET";
        stuObj.StudentAge = 29;

        // Using session
        /*HttpContext.Current.Session["FirstName"] = "Sokheng";
        HttpContext.Current.Response.Write("Helo");*/

        HttpContext.Current.Response.Write("Student's FirstName:" + stuObj.StudentFirstName + "<br/>");
        HttpContext.Current.Response.Write("Student's LastName:" + stuObj.StudentLastName + "<br/>");
        HttpContext.Current.Response.Write("Student's Email:" + stuObj.StudentEmail + "<br/>");
        HttpContext.Current.Response.Write("Student's Gender:" + stuObj.StudentGender + "<br/>");
        HttpContext.Current.Response.Write("Student's Major:" + stuObj.StudentMajor + "<br/>");
        HttpContext.Current.Response.Write("Student's Age:" + stuObj.StudentAge + "<br/>");

    }

    public static String ShowIntroduction() {
        return "This is the introduction of using this form...!";
    }

}